Archimedes Turbine by dreyfusduke on Thingiverse: https://www.thingiverse.com/thing:939532

Summary:
The Archimedes Turbine part of a design I am playing with.   3D printable (laser sintering preferable).   View Solidworks files on Grabcad here....  https://grabcad.com/library/archimedes-turbine-assembly-1  Bushing, and dowel pin part names can be matched up to McMaster-Carr Parts.  The actual blade part of the turbine is a real challenge to print FDM style. 